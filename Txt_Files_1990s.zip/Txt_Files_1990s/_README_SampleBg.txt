Dateiname 		Ext	Zul. bearb.	Format (sow. bekannt)	PUID		noch zu �ffnen
GS8_ZWKR		TXT	21.05.1994	MS Word f�r DOS 5.0	x-fmt/111	nein (nur mit Editor)
JOHN1			DOC	26.10.1991	MS Word (Version?)	fmt/37		nein (nur mit Editor)
KRETA			TXT	31.05.1993	MS Word f�r DOS 5.0	X-fmt/111	nein (nur mit Editor)
PFLANZEN		WKS	14.12.1993	MS Works (Version?)	x-fmt/118	ja (mit OpenOffice)
Prinz von Homburg	SDW	12.09.1999	StarOffice (Version?)	fmt/111		ja (mit OpenOffice)
Stundenplan 1995.ws	DOC	29.10.1995	MS Word	2.0		fmt/39		ja
