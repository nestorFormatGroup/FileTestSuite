using System;
using System.IO;

   static void Main(string[] args)
        {

Console.WriteLine("Please Test C#.");

        }